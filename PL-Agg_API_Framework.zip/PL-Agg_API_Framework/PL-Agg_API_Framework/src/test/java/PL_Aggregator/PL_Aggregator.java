package PL_Aggregator;

import java.io.FileInputStream;
import java.io.IOException;
import java.util.ArrayList;
import java.util.Properties;
import java.util.concurrent.TimeUnit;

import org.apache.log4j.Logger;
import org.apache.log4j.PropertyConfigurator;

import com.aventstack.extentreports.ExtentReports;
import com.aventstack.extentreports.ExtentTest;
import com.aventstack.extentreports.GherkinKeyword;
import com.aventstack.extentreports.reporter.ExtentHtmlReporter;

import PL_Aggregator.PL_Aggregator;
import Utility.Helper;
import cucumber.api.java.After;
import cucumber.api.java.Before;
import cucumber.api.java.en.Given;
import cucumber.api.java.en.Then;
import cucumber.api.java.en.When;
import io.restassured.RestAssured;
import io.restassured.http.Headers;
import io.restassured.response.Response;

public class PL_Aggregator {
	String URI;
	String SetSheetname;
	int RowNumVal;
	Response SerResp;
	static Properties Property = new Properties();
	static String RootFolder = System.getProperty("user.dir");
	static Logger logger;
	static ExtentHtmlReporter htmlReporter;
	public static ExtentTest feature;
	static ExtentReports extrepo = new ExtentReports();
	ExtentTest Extst;
	ExtentTest scenario;
	static String URL;
	static String Protocol;
	static String method;
	
	
	@Before
	public static void StatupConfig() throws IOException {
		
		//Initialize Logger 
		logger = Logger.getLogger(PL_Aggregator.class);
		
		// Setup Properties
		PropertyConfigurator.configure("Log4j.properties");
		
		FileInputStream PropPath = new FileInputStream(RootFolder + "\\src\\test\\java\\GenericRepository.properties");
		Property.load(PropPath);
		
		// Initialize ExtentReport
		htmlReporter = new ExtentHtmlReporter(RootFolder + Property.getProperty("apigee"));
		extrepo.attachReporter(htmlReporter);
		htmlReporter.getSystemAttributeContext();
		htmlReporter.setAppendExisting(true);
		htmlReporter.getStartTime();
		htmlReporter.getEndTime();
		htmlReporter.config().setReportName("APIGEE Test Case Report");
		htmlReporter.config().setDocumentTitle("APIGEE");

		// Assign URI and Base path to Rest Assured
		URL = Property.getProperty("MW_Entrypoint");
		
		// Protocol Use to run TC
		Protocol = Property.getProperty("RunsWith");

	}
	
	@Given("^A URI under sheet \"([^\"]*)\" from column \"([^\"]*)\" and \\\"([^\\\"]*)\\\" through (\\d+)$")
	public void a_URI_under_sheet_from_column_through(String Sheetname,int method_Col, int URIPath_Col, int RowNum) throws Throwable {
		
		RowNumVal = RowNum;
		SetSheetname = Sheetname;
		URI = Helper.getCellValue(RootFolder + Property.getProperty("JsonExcellSheet"), SetSheetname, RowNumVal,URIPath_Col);
		method = Helper.getCellValue(RootFolder + Property.getProperty("JsonExcellSheet"), SetSheetname, RowNumVal,method_Col);
		
		String TestCaseID = Helper.getCellValue(RootFolder + Property.getProperty("JsonExcellSheet"), SetSheetname,RowNumVal, 0);
		String TestCaseDesc = Helper.getCellValue(RootFolder + Property.getProperty("JsonExcellSheet"), SetSheetname,RowNumVal, 1);
		feature = extrepo.createTest(TestCaseID + ":" + TestCaseDesc);
		scenario = feature.createNode(new GherkinKeyword("Scenario"), TestCaseDesc).assignCategory("PL_Aggregator");
		scenario.createNode(new GherkinKeyword("Given"), ": Endpoint is :" + '"' + URL + URI + '"').pass("Get Entry point Succesfully");
		System.out.println(URL + URI);
		logger.info("------------------------------ Test Case Start: " + TestCaseID + ":" + TestCaseDesc+ "  ---------------------------");
	}

	
	@When("^Perform API request$")	
	public void perform_API_request() throws Throwable{
				
	if(method.equalsIgnoreCase("GET") && method != null)	
	{	
		String HeadContenttype = Helper.getCellValue(RootFolder + Property.getProperty("JsonExcellSheet"), SetSheetname,RowNumVal,8);
		String ExcelHeader4 = Helper.getCellValue(RootFolder + Property.getProperty("JsonExcellSheet"), SetSheetname, 0,8);

		try {
				Headers Reqheadpac = Helper.GenericSetHeaders(ExcelHeader4 + ":" + HeadContenttype);
				logger.info("URI is : " + URI);
				logger.info("Try to create Get Request..");
				
				if (Protocol.equalsIgnoreCase("HTTPS")) {
					SerResp = Helper.GetHTTPSRequest(Reqheadpac, URL + URI);
				} else if (Protocol.equalsIgnoreCase("HTTP")) {
					SerResp = Helper.GetRequest(Reqheadpac, URL + URI);

				}
				Helper.PrintResponselog(logger, SerResp);
				logger.info("Request made Succesfully ..");
				scenario.createNode(new GherkinKeyword("When"),
						": Perform GET method operation")
						.pass("Method initiated Succesfully");
				scenario.createNode(new GherkinKeyword("And"), ": Verify Endpoint againt the Contract Testing")
						.pass(" Service endpoint matched");

			} catch (Exception e) {
				logger.error("Request Fail...", e);
				scenario.createNode(new GherkinKeyword("When"),
						": Perform GET method operation")
						.fail("Connection refused : unable to connect Endpoint ");
				scenario.createNode(new GherkinKeyword("And"), ": Verify Endpoint againt the Contract Testing")
						.fail("Endpoint changed or Services not running");

			}
	}
	else if ( method.equalsIgnoreCase("Post") && method != null)
		{
			{
				
				String HeadContenttype = Helper.getCellValue(RootFolder + Property.getProperty("JsonExcellSheet"), SetSheetname,RowNumVal,8);
				String ExcelHeader4 = Helper.getCellValue(RootFolder + Property.getProperty("JsonExcellSheet"), SetSheetname, 0,8);
				String HeadAuthtype = Helper.getCellValue(RootFolder + Property.getProperty("JsonExcellSheet"), SetSheetname,RowNumVal,9);
				String ExcelHeader5 = Helper.getCellValue(RootFolder + Property.getProperty("JsonExcellSheet"), SetSheetname, 0,9);


				try {
						Headers Reqheadpac = Helper.GenericSetHeaders(ExcelHeader4 + ":" + HeadContenttype , ExcelHeader5+":"+ HeadAuthtype);
						logger.info("URI is : " + URI);
						logger.info("Try to create Post Request..");
						
						if (Protocol.equalsIgnoreCase("HTTPS")) {
							SerResp = Helper.PostHTTPSRequest(Reqheadpac, URL + URI);
						} else if (Protocol.equalsIgnoreCase("HTTP")) {
							SerResp = Helper.PostHTTPSRequest(Reqheadpac, URL + URI);

						}
						Helper.PrintResponselog(logger, SerResp);
						logger.info("Request made Succesfully ..");
						scenario.createNode(new GherkinKeyword("When"),
								": Perform POST method operation")
								.pass("Method initiated Succesfully");
						scenario.createNode(new GherkinKeyword("And"), ": Verify Endpoint againt the Contract Testing")
								.pass(" Service endpoint matched");

					} catch (Exception e) {
						logger.error("Request Fail...", e);
						scenario.createNode(new GherkinKeyword("When"),
								": Perform POST method operation")
								.fail("Connection refused : unable to connect Endpoint ");
						scenario.createNode(new GherkinKeyword("And"), ": Verify Endpoint againt the Contract Testing")
								.fail("Endpoint changed or Services not running");

					}
		}
    
	}
	}
	

	@Then("^verify the ResponseCode from column \"([^\"]*)\"$")
	public void verify_the_ResponseCode_from_column(int ResponseCode) throws Throwable {
		String RefRespCode = Helper.getCellValue(RootFolder + Property.getProperty("JsonExcellSheet"), SetSheetname,
				RowNumVal, ResponseCode);
		
		if (SerResp.getStatusCode() == Integer.parseInt(RefRespCode)) {
			
			System.out.println("Status Code from Server :" + SerResp.getStatusCode() + "matched");
			scenario.createNode(new GherkinKeyword("Then"), ": Validate Response code matched with " + RefRespCode)
					.pass("Response Code Matched..");
		} else {
			System.out.println("Status Code from Server :" + SerResp.getStatusCode() +" didnot match..");
			scenario.createNode(new GherkinKeyword("Then"), ": Validate Response code matched with " + RefRespCode)
					.fail("Server reponse Code " + SerResp.getStatusCode());
			

		}

	}
	
	@Then("^verify the ResponseHeader from (\\d+) (\\d+) (\\d+) (\\d+)$")
	public void verify_the_ResponseHeader_from(int Head1, int Head2, int Head3, int Head4) throws Throwable {
		
		ArrayList<Integer> Headers = new ArrayList<Integer>();
		Headers.add(Head1);  
		Headers.add(Head2);
		Headers.add(Head3);
		Headers.add(Head4);

		for (int i = 0; i < Headers.size(); i++) {
	       	        
	      String ResponseHeader = Helper.getCellValue(RootFolder + Property.getProperty("JsonExcellSheet"), SetSheetname, 0,Headers.get(i));
		  String ResponseHeaderVal = Helper.getCellValue(RootFolder + Property.getProperty("JsonExcellSheet"), SetSheetname,RowNumVal, Headers.get(i));
 	      String ServerResponseHeader = SerResp.getHeader(ResponseHeader);

	      
	      if (ServerResponseHeader.equals(ResponseHeaderVal)) {
				scenario.createNode(new GherkinKeyword("Then"), ": Validate Response Header value matched with : " + ResponseHeaderVal)
						.pass("Header Value Matched");
			} else {
				scenario.createNode(new GherkinKeyword("Then"), ": Validate Response Header value matched with : " + ResponseHeaderVal)
						.fail("Server Response Header Value : " + ServerResponseHeader);
			}

		}


	}
	
	@Then("^verify Response Time$")
	public void verify_Response_Time() throws Throwable  {

		String ExpectedResponseTime = Helper.getCellValue(RootFolder + Property.getProperty("JsonExcellSheet"), SetSheetname,RowNumVal,9);
		
		if(SerResp.getTimeIn(TimeUnit.MILLISECONDS) <= Integer.parseInt(ExpectedResponseTime)) {
			 scenario.createNode(new GherkinKeyword("Then"), ": Validate Response Time equal and less than : " + ExpectedResponseTime+" ms")
			.pass("Response Time As Expected ");
			
		}else {
			scenario.createNode(new GherkinKeyword("Then"), ": Server Response Time not matched with Expected Response Time , Expected : " + ExpectedResponseTime+" ms")
			.fail("Server Response Time : " + SerResp.getTimeIn(TimeUnit.MILLISECONDS)+" ms");
		}
		
	}
	
	
	@After
	public static void TearDown() throws IOException {
		extrepo.flush();

	}
}
