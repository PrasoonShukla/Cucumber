package Utility;

import org.junit.runner.RunWith;

import cucumber.api.CucumberOptions;
import cucumber.api.junit.Cucumber;

@RunWith(Cucumber.class)

@CucumberOptions(
plugin = { "html:CucumberOutput/cucumber-html-report",
        "json:CucumberOutput/cucumber.json", "pretty:CucumberOutput/cucumber-pretty.txt",
        "usage:CucumberOutput/cucumber-usage.json",
        "junit:CucumberOutput/cucumber-results.xml"
        },
tags = {"@regression"},
dryRun = false,
glue = {"PL_Aggregator"},
features = {"Feature_Repository/PL_Aggregator/PL_Aggregator.feature"}
)

public class Suite_Runner {

}
