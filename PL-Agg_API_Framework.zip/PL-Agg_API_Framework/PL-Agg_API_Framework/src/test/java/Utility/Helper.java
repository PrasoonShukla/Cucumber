package Utility;

import java.io.FileInputStream;
import java.io.IOException;
import org.apache.log4j.Logger;
import org.apache.poi.openxml4j.exceptions.InvalidFormatException;
import org.apache.poi.ss.usermodel.Cell;
import org.apache.poi.ss.usermodel.Workbook;
import org.apache.poi.ss.usermodel.WorkbookFactory;


import io.restassured.http.Header;
import io.restassured.http.Headers;

import io.restassured.response.Response;
import static io.restassured.RestAssured.given;


public class Helper {

	public static String getCellValue(String input_file_path_xls, String sheet_name, int row_Num, int row_cell_Num)
			throws InvalidFormatException, IOException {
		
		FileInputStream fileInputStream = new FileInputStream(input_file_path_xls);
		Workbook wb = WorkbookFactory.create(fileInputStream);
		int type = wb.getSheet(sheet_name).getRow(row_Num).getCell(row_cell_Num).getCellType();
		String Cell_value = "";
		if (type == Cell.CELL_TYPE_STRING) {
			Cell_value = wb.getSheet(sheet_name).getRow(row_Num).getCell(row_cell_Num).getStringCellValue();
			// System.out.println("string:"+Cell_value);

		} else if (type == Cell.CELL_TYPE_NUMERIC) {
			int Cell_num_Value = (int) wb.getSheet(sheet_name).getRow(row_Num).getCell(row_cell_Num)
					.getNumericCellValue();
			Cell_value = "" + Cell_num_Value;
			// System.out.println("Num:"+Cell_value);
		} else if (type == Cell.CELL_TYPE_BLANK) {
			Cell_value = wb.getSheet(sheet_name).getRow(row_Num).getCell(row_cell_Num).getStringCellValue();
			System.out.println("Blank cell");
		}

		return Cell_value;
	}

	public static Response GetRequest(Headers ReqHeader, String Endpoint) {

		Response GetResponse = given().headers(ReqHeader).log().all().when().get(Endpoint).andReturn();

		return GetResponse;
	}

	public static Response GetHTTPSRequest(Headers ReqHeader, String Endpoint) {

		Response GetResponse = given().
				relaxedHTTPSValidation().
				headers(ReqHeader).
				log().
				all().
				when().
				get(Endpoint).
				andReturn();

		return GetResponse;
	}
	
	public static Response PostHTTPSRequest(Headers ReqHeader, String Endpoint) {
		
		Response PostResponse = given().
				headers(ReqHeader).
				queryParam("grant_type", "client_credential").
				when().log().all().
				post(Endpoint+ReqHeader).
				then().
				extract().
				response().
				andReturn();
		
		return PostResponse;
	}
	
	
	public static Response PostHTTPSRequest(Headers ReqHeader, String Endpoint, String Query_param_key, String Query_param) {
		
		Response PostResponse = given().
				headers(ReqHeader).
				queryParam( Query_param_key, Query_param).
				when().log().all().
				post(Endpoint+ReqHeader).
				then().
				extract().
				response().
				andReturn();
		
		return PostResponse;
	}

		
	public static void PrintResponselog(Logger log, Response ServiceResponse) {
		log.info("Server Status Code -----> " + ServiceResponse.getStatusCode());
		log.info("Server Response -----:\n" + ServiceResponse.prettyPrint());
	}

	
	public static Headers GenericSetHeaders(String Head1) {

		String[] RawHead = Head1.split(":");
		
		final Header head1 = new Header(RawHead[0].trim(), RawHead[1].trim());
		

		Headers Reqheadpac = new Headers(head1);

		return Reqheadpac;
	}
	
	public static Headers GenericSetHeaders(String Head1, String Head2) {

		String[] RawHead = Head1.split(":");
		String[] RawHead1 = Head2.split(":");

		final Header head1 = new Header(RawHead[0].trim(), RawHead[1].trim());
		final Header head2 = new Header(RawHead1[0].trim(), RawHead1[1].trim());

		Headers Reqheadpac = new Headers(head1, head2);

		return Reqheadpac;
	}

	
		
}
