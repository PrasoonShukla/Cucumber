﻿using NUnit.Framework;
using System;
using TechTalk.SpecFlow;

namespace SpecflowBasic.steps
{
    [Binding]
    public class CalculatorFeatureSteps
    {
        // instantiating application instance 
        CalculatorApplication app = new CalculatorApplication();

        // variables to hold input values and the intermeditate result 
        int input1, input2;
        double output;

        [Given(@"I have provided (.*) and (.*) as the inputs")]
        public void GivenIHaveProvidedAndAsTheInputs(int p0, int p1)
        {
            input1 = p0;
            input2 = p1;

            /*ScenarioContext.Current.Pending();*/
        }

        [Given(@"I have provided (.*) as input")]
        public void GivenIHaveProvidedAsInput(int p0)
        {
            input1 = p0;
           /* ScenarioContext.Current.Pending();*/
        }

        [When(@"I press add")]
        public void WhenIPressAdd()
        {
            output = app.add(input1, input2);
            /*ScenarioContext.Current.Pending();*/
        }
        
        [When(@"I press substract")]
        public void WhenIPressSubstract()
        {
            output = app.subsctract(input1, input2);
            /*ScenarioContext.Current.Pending();*/
        }
        
        [When(@"I press multiply")]
        public void WhenIPressMultiply()
        {
            output = app.multiply(input1, input2);
            /*ScenarioContext.Current.Pending();*/
        }
        
        [When(@"I press divide")]
        public void WhenIPressDivide()
        {
            output = app.divide(input1, input2);
            /*ScenarioContext.Current.Pending();*/
        }
        
        [When(@"I press squareroot")]
        public void WhenIPressSquareroot()
        {
            output = app.squareRoot(input1);
            /*ScenarioContext.Current.Pending();*/
        }
        
        [Then(@"the result should be (.*)")]
        public void ThenTheResultShouldBe(Double p0)
        {
            Assert.AreEqual(p0, output);
            /*ScenarioContext.Current.Pending();*/
        }
      
    }
}
